import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-select-invoice',
  templateUrl: './select-invoice.component.html',
  styleUrls: ['./select-invoice.component.css']
})
export class SelectInvoiceComponent implements OnInit {
mobile;
userEntry;
  constructor(private _demoService: DataService) { }

  ngOnInit() {
  }
  verifyUser(){
    this._demoService.customerExist(this.mobile).subscribe(
       data => {
         alert('success');
       },
       error => {
        this.userEntry = true;
       }
    );
  }


}
