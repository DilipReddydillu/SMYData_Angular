import { Component, OnInit } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import {BillingService} from '../billing.service';


@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.css']
})
export class InvoiceComponent implements OnInit {
name;
mobile;
email;
allCookies;
items;
total;
discount;
invoiceData;
invoiceGenerate;
subTotal:any;
  constructor(private _billingService: BillingService, private cookieService: CookieService) {
  }

  ngOnInit() {
    this.name = "David";
    this.allCookies = this.cookieService.getAll();
    this.mobile = this.allCookies.mobile;
    this.items = ['chair','bean','desk','sofa'];
  }

  public invoice:any = [{
    item:'', quantity:'', rate:'',
    total:''
  }];


  addRow(){
    this.invoice.push({
      item:'', quantity:'', rate:'',
      total:''
    });
  };

  deleteRow(index){
    this.invoice.splice(index,1);
  };
  submitInvoice(){
    this.invoice.push({discount:this.discount});
    this._billingService.addInvoice(this.invoice).subscribe(
       data => {
         console.log('success::'+data)
         this.invoiceGenerate = true;
         this.name = data[0].userName;
         this.mobile = data[0].userMobile;
         this.email = data[0].email;
          alert('saved successfully');
       },
       error => {
         alert('could not create Invoice! try again!!')
       }
    );

  }

}
