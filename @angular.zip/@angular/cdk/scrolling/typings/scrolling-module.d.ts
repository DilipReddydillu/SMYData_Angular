export declare class ScrollDispatchModule {
}
