export declare class CdkStepperModule {
}
