export declare class CdkAccordionModule {
}
