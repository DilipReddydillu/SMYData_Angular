export declare class PlatformModule {
}
