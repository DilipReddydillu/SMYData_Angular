import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-individual-details',
  templateUrl: './individual-details.component.html',
  styleUrls: ['./individual-details.component.css']
})
export class IndividualDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
